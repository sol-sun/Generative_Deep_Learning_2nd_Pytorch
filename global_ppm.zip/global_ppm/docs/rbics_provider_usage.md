# RBICSプロバイダー使用ガイド

## 概要

RBICSプロバイダーは、FactSet REVEREデータベースからRBICS（Revenue Business Industry Classification System）分類データを高速かつ安全に取得するためのプロバイダーです。

## 主要機能

- **RBICS構造マスタ取得**: セクター体系の階層構造情報
- **企業売上セグメント取得**: 企業の事業セグメント別売上情報
- **企業フォーカス取得**: 企業の主力事業分類情報
- **WolfPeriod対応**: 統一された期間管理
- **高性能処理**: バッチ処理・並列化・キャッシュ最適化

## 基本的な使用方法

### 1. プロバイダーの初期化

```python
from gppm.providers.rbics_provider import RBICSProvider

# プロバイダーの初期化（並列数指定可能）
provider = RBICSProvider(max_workers=4)
```

### 2. RBICS構造マスタの取得

```python
from wolf_period import WolfPeriod
from datetime import date

# 特定日時点でのRBICS構造マスタを取得
structure_records = provider.get_structure_records(
    period=WolfPeriod.from_day(date(2023, 12, 31))
)

# 結果の確認
for record in structure_records[:5]:
    print(f"L6: {record.l6_id} - {record.l6_name}")
    print(f"L1: {record.l1_id} - {record.l1_name}")
    print(f"説明: {record.sector_description}")
    print("---")
```

### 3. 企業の売上セグメント情報取得

```python
from gppm.providers.rbics_types import SegmentType

# 特定企業の売上セグメント情報を取得
revenue_records = provider.get_company_records(
    segment_types=[SegmentType.REVENUE],
    company_ids=["123456789", "987654321"],
    min_revenue_share=0.05,  # 売上シェア5%以上
    period=WolfPeriod.from_day(date(2023, 12, 31))
)

# 結果の確認
for record in revenue_records:
    print(f"企業: {record.company_name} ({record.company_id})")
    print(f"セグメント: {record.segment_name}")
    print(f"売上シェア: {record.revenue_share:.2%}")
    print(f"RBICS L6: {record.rbics_l6_id}")
    print("---")
```

### 4. 企業のフォーカス情報取得

```python
# 特定地域の企業フォーカス情報を取得
focus_records = provider.get_company_records(
    segment_types=[SegmentType.FOCUS],
    region_codes=["USA", "JPN"],
    period=WolfPeriod.from_day(date(2023, 12, 31))
)

# 結果の確認
for record in focus_records:
    print(f"企業: {record.company_name}")
    print(f"地域: {record.region_name} ({record.region_code})")
    print(f"主力事業 RBICS L6: {record.rbics_l6_id}")
    print("---")
```

## 高度な使用方法

### 期間範囲指定

```python
from wolf_period import WolfPeriodRange

# 期間範囲での取得
start_period = WolfPeriod.from_month(2023, 1)
end_period = WolfPeriod.from_month(2023, 12)
period_range = WolfPeriodRange(start_period, end_period)

records = provider.get_company_records(
    segment_types=[SegmentType.REVENUE, SegmentType.FOCUS],
    period=period_range,
    batch_size=5000  # パフォーマンス調整
)
```

### 複数の条件でフィルタリング

```python
# 複合条件での取得
records = provider.get_company_records(
    segment_types=[SegmentType.REVENUE],
    security_ids=["US0378331005", "JP3633400001"],  # ISIN指定
    identifier_type="isin",
    min_revenue_share=0.10,
    exclude_zero_revenue=True,
    region_codes=["USA", "JPN"],
    batch_size=2000
)
```

### パラメータオブジェクトの使用

```python
from gppm.providers.rbics_types import RBICSQueryParams

# パラメータオブジェクトでの指定
params = RBICSQueryParams(
    segment_types=[SegmentType.REVENUE],
    company_ids=["123456789"],
    min_revenue_share=0.05,
    period=WolfPeriod.from_day(date(2023, 12, 31)),
    batch_size=1000
)

records = provider.get_company_records(params)
```

## データモデル

### RBICSStructureRecord

RBICS構造マスタの情報を保持します。

```python
record = structure_records[0]

# 階層情報へのアクセス
print(f"L1コード: {record.l1_id}, 名称: {record.l1_name}")
print(f"L6コード: {record.l6_id}, 名称: {record.l6_name}")

# 計算済みプロパティ
print(f"主要セクター: {record.primary_sector}")
print(f"分類レベル: {record.classification_level}")
print(f"取得期間: {record.period_label}")
```

### RBICSCompanyRecord

企業のRBICS分類情報を保持します。

```python
record = revenue_records[0]

# 企業基本情報
print(f"企業ID: {record.company_id}")
print(f"企業名: {record.company_name}")
print(f"FactSet Entity ID: {record.factset_entity_id}")

# 証券識別子
print(f"ISIN: {record.isin}")
print(f"ティッカー: {record.ticker}")
print(f"主要識別子: {record.primary_identifier}")

# RBICS情報
print(f"セグメントタイプ: {record.segment_type}")
print(f"RBICS L6: {record.rbics_l6_id}")
print(f"売上セグメント: {record.is_revenue_segment}")

# セグメント詳細（売上セグメントの場合）
if record.is_revenue_segment:
    print(f"セグメント名: {record.segment_name}")
    print(f"売上シェア: {record.revenue_share:.2%}")
```

## エラーハンドリング

```python
from pydantic import ValidationError

try:
    records = provider.get_company_records(
        segment_types=[SegmentType.REVENUE],
        company_ids=["invalid_id"],
        min_revenue_share=1.5  # 無効な値（>1.0）
    )
except ValidationError as e:
    print(f"バリデーションエラー: {e}")
    
except Exception as e:
    print(f"データベースエラー: {e}")
```

## パフォーマンス調整

### バッチサイズの調整

```python
# 大量データ処理の場合
records = provider.get_company_records(
    segment_types=[SegmentType.REVENUE],
    batch_size=10000  # バッチサイズを増加
)

# メモリ制約がある場合
records = provider.get_company_records(
    segment_types=[SegmentType.REVENUE],
    batch_size=500   # バッチサイズを減少
)
```

### 並列度の調整

```python
# 高並列処理用
provider = RBICSProvider(max_workers=8)

# 単一スレッド処理用
provider = RBICSProvider(max_workers=1)
```

## データ品質フィルタ

```python
# 高品質データのみ取得
records = provider.get_company_records(
    segment_types=[SegmentType.REVENUE],
    min_revenue_share=0.10,      # 売上シェア10%以上
    exclude_zero_revenue=True,   # 売上ゼロを除外
    region_codes=["USA", "JPN"]  # 特定地域のみ
)
```

## 後方互換性

旧形式のAPIも引き続きサポートされています：

```python
# 旧形式（非推奨）
records = provider.get_company_records(
    segment_type=SegmentType.REVENUE,  # 単数形
    company_id="123456789",            # 単数形
    as_of_date=date(2023, 12, 31)     # 旧形式の日付指定
)

# 新形式（推奨）
records = provider.get_company_records(
    segment_types=[SegmentType.REVENUE],  # 複数形
    company_ids=["123456789"],            # 複数形
    period=WolfPeriod.from_day(date(2023, 12, 31))  # WolfPeriod
)
```

## 制約事項

- **並列度**: 最大8以下（推奨: 4）
- **バッチサイズ**: 1,000〜10,000（推奨: 1,000-5,000）
- **企業ID**: REVERE固有の識別子（数値文字列）
- **データベース接続**: 同時接続数制限あり

## トラブルシューティング

### よくある問題

1. **データが取得できない**
   - 期間指定を確認
   - 企業IDの形式を確認
   - データベース接続を確認

2. **パフォーマンスが遅い**
   - バッチサイズを調整
   - 並列度を調整
   - フィルタ条件を適切に設定

3. **メモリ不足**
   - バッチサイズを減少
   - 期間範囲を縮小
   - 不要なフィルタを除去

### ログ出力の確認

```python
import logging

# ログレベルを設定してデバッグ情報を確認
logging.getLogger('gppm.providers.rbics_provider').setLevel(logging.DEBUG)

records = provider.get_company_records(
    segment_types=[SegmentType.REVENUE],
    company_ids=["123456789"]
)
```
