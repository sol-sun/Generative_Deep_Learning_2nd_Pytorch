"""
GIB_DB 接続（読み取り専用）
"""

from gppm.providers.sqlserver import SQLServer


class AISGGibDB(SQLServer):
    def __init__(self):
        self.host = '172.22.200.25'
        self.port = '1433'
        self.username = 'READ_MASTER'
        self.password = 'MASTER_READ123'
        super().__init__(host=self.host, port=self.port, username=self.username, password=self.password)


