"""
REVEREデータプロバイダー

FactSet REVEREデータベースからセグメントデータを取得・処理
"""

import pandas as pd
from gppm.utils.data_processor import DataProcessor


class RevereDataProvider(DataProcessor):
    """REVEREデータの処理"""
    
    def get_revere_data(self) -> pd.DataFrame:
        """REVEREセグメントデータの取得"""
        sql = """
        SELECT DISTINCT
            F.COMPANY_ID,
            G.FS_ENTITY_ID AS FACTSET_ENTITY_ID,
            D.NAME AS COMPANY_NAME,
            D.SEDOL, D.TICKER, D.ISIN, D.CUSIP,
            H.NAME AS REGION_NAME,
            H.DOME_REGION AS REGION_CODE,
            H.COUNTRY AS HQ_REGION_CODE,
            A.PERIOD_END_DATE,
            B.ID   AS SEGMENT_ID,
            B.NAME AS SEGMENT_NAME,
            B.TYPE,
            B.REVENUE_PERCENT AS SEG_SHARE,
            B.RBICS2_L6_ID AS REVENUE_L6_ID
        FROM FACTSET_REVERE.COMPANY_RBICS2_BUS_SEG_REPORT A
        INNER JOIN (
            SELECT
                COMPANY_ID,
                MAX(PERIOD_END_DATE) AS PERIOD_END_DATE,
                MAX(STARTS) AS STARTS
            FROM FACTSET_REVERE.COMPANY_RBICS2_BUS_SEG_REPORT
            GROUP BY COMPANY_ID
        ) F ON A.COMPANY_ID = F.COMPANY_ID
        INNER JOIN FACTSET_REVERE.COMPANY_RBICS2_BUS_SEG_ITEM B
            ON A.ID = B.REPORT_ID
        INNER JOIN FACTSET_REVERE.COMPANY_FACTSET G
            ON A.COMPANY_ID = G.COMPANY_ID
        WHERE A.PERIOD_END_DATE >= CONVERT(DATETIME, '2017-04-01 00:00:00')
          AND B.TYPE != 'N'
        """
        
        df = self.db.execute_query(sql)
        return self._process_revere_data(df)
    
    def _process_revere_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """REVEREデータの処理"""
        df = df.copy()
        
        # セグメント名の正規化
        df["SEGMENT_NAME"] = df["SEGMENT_NAME"].str.strip()
        df["SEGMENT_NAME"] = df["SEGMENT_NAME"].str.replace(r"[—–]", "-", regex=True)
        df["SEGMENT_NAME"] = df["SEGMENT_NAME"].str.replace(r"(\w)\s", r"\1 ", regex=True)
        
        # 売上比率と会計年度の計算
        df["SALES_RATIO"] = df["SEG_SHARE"].astype(float) / 100
        
        # WolfPeriodを使用した会計年度計算
        from wolf_period import WolfPeriod, Frequency
        def get_fiscal_year_from_date(date):
            """日付から会計年度を取得"""
            date_obj = pd.to_datetime(date).date()
            period = WolfPeriod.from_day(date_obj, freq=Frequency.Y, fy_start_month=4)
            return period.y
        
        df["FISCAL_YEAR"] = df["PERIOD_END_DATE"].map(get_fiscal_year_from_date)
        
        # セグメントシェアの合計計算
        df["SEG_SHARE_SUM"] = (
            df.groupby(["FACTSET_ENTITY_ID", "FISCAL_YEAR"])["SEG_SHARE"].transform("sum")
        )
        
        df.sort_values(by=["FACTSET_ENTITY_ID", "FISCAL_YEAR", "SALES_RATIO"], inplace=True)
        
        # 冗長な行の除去とセグメント名の処理
        df = df.groupby(['FACTSET_ENTITY_ID', 'FISCAL_YEAR'], group_keys=False).apply(
            self._remove_redundant_rows
        )
        
        return df
    
    def _remove_redundant_rows(self, group):
        """重複するセグメント行の除去"""
        flag = group["SEG_SHARE"].sum() != 1
        indices_to_remove = []
        
        for idx, seg in group["SEGMENT_NAME"].items():
            search_str = seg + " "
            if not flag:
                if any(other_seg.startswith(search_str) for j, other_seg in group["SEGMENT_NAME"].items() if j != idx):
                    indices_to_remove.append(idx)
            
            for j, other_seg in group["SEGMENT_NAME"].items():
                if other_seg.startswith(search_str):
                    if not other_seg.startswith(seg + " - "):
                        updated_seg = seg + " - " + other_seg[len(seg):].lstrip()
                        group.at[j, "SEGMENT_NAME"] = updated_seg
        
        return group.drop(indices_to_remove)


