"""
データ処理の基底クラス
"""

import pandas as pd
import unicodedata
from gppm.providers.aisg_gib_db import AISGGibDB


class DataProcessor:
    """データ処理のための基底クラス"""
    
    def __init__(self):
        self.db = AISGGibDB()
    
    @staticmethod
    def normalize_text(s):
        if isinstance(s, str):
            s_lower = s.lower()
            return unicodedata.normalize('NFKC', s_lower)
        return s
    
    @staticmethod
    def filter_func(group):
        if group["FSYM_ID"].nunique() > 1:
            return group[group["PRIMARY_EQUITY_FLAG"] == 1]
        else:
            return group
    
    @staticmethod
    def adjust_fiscal_term(df: pd.DataFrame, date_col: str = "DATE") -> pd.DataFrame:
        _MONTH_MAP = {1: 3, 2: 3, 3: 3, 4: 6, 5: 6, 6: 6, 7: 9, 8: 9, 9: 9, 10: 12, 11: 12, 12: 12}
        df = df.copy()
        df["FTERM"] = pd.to_datetime(df[date_col])
        df["FTERM_2"] = (
            df["FTERM"].dt.year.astype(str) + df["FTERM"].dt.month.map(lambda m: "{:02}".format(_MONTH_MAP[m]))
        ).astype(int)
        from wolf_period import WolfPeriod, Frequency
        
        def get_fiscal_year_from_yyyymm(yyyymm):
            """YYYYMM形式から会計年度を取得"""
            # 月次期間を作成してfiscal_yearプロパティを直接使用
            period = WolfPeriod.from_yyyymm(yyyymm, freq=Frequency.M)
            return period.fiscal_year
        
        df["FISCAL_YEAR"] = df["FTERM_2"].map(get_fiscal_year_from_yyyymm)
        return df
    
    @staticmethod
    def remove_duplicate_periods(df: pd.DataFrame, 
                               group_cols: list = None, 
                               date_col: str = "DATE",
                               period_col: str = "FTERM_2") -> pd.DataFrame:
        if group_cols is None:
            group_cols = ["FSYM_ID", "FACTSET_ENTITY_ID"]
        available_group_cols = [col for col in group_cols if col in df.columns]
        if not available_group_cols:
            print("警告: 指定されたグループカラムが見つかりません。FSYM_IDのみを使用します。")
            available_group_cols = ["FSYM_ID"] if "FSYM_ID" in df.columns else []
        if not available_group_cols:
            print("エラー: グループ化できるカラムがありません。")
            return df
        df_result = df.copy()
        df_result[date_col] = pd.to_datetime(df_result[date_col])
        duplicate_groups = (
            df_result.groupby(available_group_cols + [period_col])
            .size()
            .reset_index(name='count')
            .query('count > 1')
        )
        if len(duplicate_groups) == 0:
            print("重複する会計期間データは見つかりませんでした。")
            return df_result
        print(f"重複データが見つかりました: {len(duplicate_groups)} グループ")
        df_result = (
            df_result.sort_values(available_group_cols + [period_col, date_col])
            .groupby(available_group_cols + [period_col], group_keys=False)
            .tail(1)
            .reset_index(drop=True)
        )
        removed_count = len(df) - len(df_result)
        print(f"重複除去完了: {removed_count} 件のレコードを除去しました。")
        return df_result


