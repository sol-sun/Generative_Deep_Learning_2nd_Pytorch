#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: scripts/jupyter_nohup.sh [options]

Options:
  --mode lab|notebook     Jupyter モード (default: lab)
  --port N                ポート番号 (default: 10017)
  --ip ADDRESS            バインド IP (default: 0.0.0.1)
  --dir PATH              notebooks ルート (default: notebooks)
  --no-token              トークン認証を無効化
  --log FILE              ログファイルパス (default: logs/jupyter_<mode>_<port>.log)
  --py-path DIR           PYTHONPATH に追加するパス (default: src)
  -h, --help              このヘルプを表示

Examples:
  bash scripts/jupyter_nohup.sh --port 10017 --dir notebooks
  bash scripts/jupyter_nohup.sh --mode lab --ip 0.0.0.0 --no-token
EOF
}

MODE="lab"
PORT="10017"
IP="0.0.0.0"
DIR="notebooks"
NO_TOKEN="false"
LOG=""
PY_PATH="src"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --mode)
      MODE="${2:-lab}"; shift 2;;
    --port)
      PORT="${2:-10017}"; shift 2;;
    --ip)
      IP="${2:-0.0.0.0}"; shift 2;;
    --dir|--notebook-dir)
      DIR="${2:-notebooks}"; shift 2;;
    --no-token)
      NO_TOKEN="true"; shift;;
    --log)
      LOG="${2:-}"; shift 2;;
    --py-path)
      PY_PATH="${2:-src}"; shift 2;;
    -h|--help)
      usage; exit 0;;
    *)
      echo "Unknown option: $1" >&2; usage; exit 1;;
  esac
done

# 入力の妥当性チェック
if [[ "$MODE" != "lab" && "$MODE" != "notebook" ]]; then
  echo "--mode は lab | notebook のみ対応です。" >&2; exit 1
fi
if ! [[ "$PORT" =~ ^[0-9]+$ ]]; then
  echo "--port には数値を指定してください。" >&2; exit 1
fi

# uv の存在チェック（インストール案内を現実に合わせる）
if ! command -v uv >/dev/null 2>&1; then
  echo "uv が見つかりません。先に 'pip install uv'（または 'brew install uv'）を実行してください。" >&2
  exit 1
fi

# ログファイルパスの決定とディレクトリ作成
if [[ -z "$LOG" ]]; then
  LOG="logs/jupyter_${MODE}_${PORT}.log"
fi
mkdir -p "$(dirname "$LOG")"

# ポート使用中チェック
is_port_in_use() {
  if command -v lsof >/dev/null 2>&1; then
    lsof -iTCP:"$PORT" -sTCP:LISTEN -nP >/dev/null 2>&1
  elif command -v ss >/dev/null 2>&1; then
    ss -ltn "sport = :$PORT" 2>/dev/null | grep -q LISTEN
  elif command -v netstat >/dev/null 2>&1; then
    netstat -an 2>/dev/null | grep -q "[.:]$PORT .*LISTEN"
  else
    return 1  # 未検証（ツールなし）はスキップ
  fi
}
if is_port_in_use; then
  echo "ポート :$PORT は使用中です。--port で変更してください。" >&2
  exit 1
fi

# PYTHONPATH の設定（絶対/相対/ホームディレクトリの対応）
if [[ "${PY_PATH}" == /* ]]; then
  # 絶対パス
  PYTHONPATH="${PY_PATH}"
elif [[ "${PY_PATH}" == ~* ]]; then
  # ホームディレクトリ（~）で始まる場合
  PYTHONPATH="${PY_PATH/#\~/$HOME}"
else
  # 相対パスの場合、プロジェクトルートからのパスとして扱う
  PROJECT_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
  PYTHONPATH="${PROJECT_ROOT}/${PY_PATH}"
fi

# コマンド組み立て（必要パッケージを --with で解決）
WITH_ARGS=()
if [[ "$MODE" == "lab" ]]; then
  WITH_ARGS+=(--with jupyterlab)
else
  WITH_ARGS+=(--with notebook)
fi

cmd=(uv run "${WITH_ARGS[@]}" jupyter "$MODE" --no-browser --ip="$IP" --port="$PORT" \
     --ServerApp.root_dir="$DIR")

# トークン無効化
if [[ "$NO_TOKEN" == "true" ]]; then
  cmd+=(--ServerApp.token='')
fi

# 付加情報をログに書き込む
{
  echo "== jupyter_nohup.sh starting =="
  date -Iseconds
  echo "MODE=$MODE"
  echo "PORT=$PORT"
  echo "IP=$IP"
  echo "DIR=$DIR"
  echo "PYTHONPATH=$PYTHONPATH"
} > "$LOG"

# 起動
echo "PYTHONPATH を設定: ${PYTHONPATH}"
nohup env PYTHONPATH="${PYTHONPATH}" "${cmd[@]}" > "$LOG" 2>&1 &
PID=$!

echo "Jupyter ${MODE} を起動しました (PID: $PID)"
echo "ログ: $LOG"

# Linux での IP 取得
get_ip() {
  if command -v hostname >/dev/null 2>&1 && hostname -I >/dev/null 2>&1; then
    hostname -I | awk '{print $1}'
  elif command -v ip >/dev/null 2>&1; then
    ip -4 addr show scope global 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1 | head -n1
  else
    echo ""
  fi
}
SRV_IP="$(get_ip)"
echo "URL: http://${SRV_IP:-localhost}:${PORT}"