"""
WolfPeriodパッケージ

金融・ビジネス分析に特化した期間処理ライブラリ

提供機能：
- WolfPeriod: 期間を表すクラス（日/週/月/四半期/年をサポート）
- WolfPeriodRange: WolfPeriodの範囲を表すクラス
- Frequency: 期間の頻度を表すEnum
- Weekday: 曜日を表すEnum
- QuarterIndex: 四半期インデックスを表すEnum
- CalendarConfig: カレンダー設定を管理するクラス

主要な使用シーン：
- 財務分析: 月次・四半期・年次レポートの期間管理
- ビジネス分析: 週次・月次KPIの期間設定
- データ処理: 期間ベースのデータフィルタリング・集計

使用例：
    from wolf_period import WolfPeriod, WolfPeriodRange, Frequency
    
    # 月次期間の作成
    period = WolfPeriod.from_month(2023, 12)
    
    # 期間範囲の作成
    range_obj = WolfPeriodRange(
        WolfPeriod.from_month(2023, 1),
        WolfPeriod.from_month(2023, 12)
    )
    
    # 頻度の指定
    freq = Frequency.MONTHLY
"""

# 主要なクラスとEnumをインポート
from .periods import WolfPeriod
from .ranges import WolfPeriodRange
from .types import Frequency, Weekday, QuarterIndex, CalendarConfig

# パッケージのバージョン
__version__ = "1.0.0"

# パブリックAPIとして公開するクラスとEnum
__all__ = [
    "WolfPeriod",
    "WolfPeriodRange", 
    "Frequency",
    "Weekday",
    "QuarterIndex",
    "CalendarConfig",
]
