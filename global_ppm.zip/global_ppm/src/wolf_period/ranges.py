"""
WolfPeriodRange: 期間範囲の効率的な処理と操作

概要
-----
WolfPeriodオブジェクトの範囲を効率的に処理し、金融・ビジネス分析における
期間シーケンスの操作を簡素化します。
WolfPeriodの型安全性と柔軟性を活用した高度な期間範囲操作を提供します。

主要機能
--------
• 範囲生成: 開始・終了期間、ステップ、期間数による柔軟な範囲定義
• 範囲操作: head/tail、インデックスアクセス、スライス操作
• 包含判定: 期間が範囲に含まれるかの効率的な判定
• pandas連携: Index、DataFrameとの相互変換
• 逆順処理: 降順での期間生成と操作

使用例
------
>>> from datetime import date
>>> start = WolfPeriod.from_month(2024, 1, freq=Frequency.M)
>>> end = WolfPeriod.from_month(2024, 12, freq=Frequency.M)
>>> range_obj = WolfPeriodRange(start, end, step=1)  # 位置引数使用
>>> # または
>>> range_obj = WolfPeriodRange(start=start, stop=end, step=1)  # キーワード引数使用
>>> # または
>>> range_obj = WolfPeriodRange(start=start, count=12)  # count使用
>>> months = range_obj.to_list()  # 12ヶ月のリスト
>>> first_quarter = range_obj[:3]  # 最初の3ヶ月
"""

from typing import Iterator, Optional, Iterable, overload, Sequence, Any
from pydantic import BaseModel, ConfigDict, field_validator, computed_field, model_validator
import pandas as pd
from datetime import date, datetime

from .types import Frequency
from .periods import WolfPeriod

class WolfPeriodRange(BaseModel):
    """WolfPeriodの範囲を表すクラス。
    
    期間の範囲を効率的にイテレートし、便利な操作を提供します。
    金融・ビジネス分析での期間範囲処理に特化しています。
    
    Attributes
    ----------
    start : WolfPeriod
        範囲の開始期間
    stop : Optional[WolfPeriod]
        範囲の終了期間（Noneの場合はcountが必須）
    step : int
        ステップサイズ（デフォルト: 1）
    count : Optional[int]
        生成する期間数（指定された場合）
    """
    model_config = ConfigDict(frozen=True)  # イミュータブル設定

    start: "WolfPeriod"
    stop: Optional["WolfPeriod"] = None
    step: int = 1
    count: Optional[int] = None  # 指定された場合の生成期間数

    # ---------- 検証 ----------
    @field_validator("step")
    @classmethod
    def _check_step(cls, v: int) -> int:
        """ステップサイズの妥当性をチェックします。"""
        if v == 0:
            raise ValueError("ステップを0にすることはできません")
        return v

    @field_validator("stop")
    @classmethod
    def _check_mode(cls, stop: Optional["WolfPeriod"], info) -> Optional["WolfPeriod"]:
        """開始と終了期間のモード互換性をチェックします。"""
        start: "WolfPeriod" = info.data.get("start")  # type: ignore
        if stop is not None and start is not None:
            start._ensure_same_mode(stop)
        return stop

    @model_validator(mode="after")
    def _validate_stop_or_count(self):
        """stopまたはcountのいずれかが必須であることを検証します。"""
        if self.stop is None and self.count is None:
            raise ValueError("stopまたはcountのいずれかを指定してください")
        return self

    def __init__(self, start=None, stop=None, *, step=1, count=None, **kwargs):
        """位置引数とキーワード引数の両方をサポートするコンストラクタ
        
        以下の呼び出し方法をサポートします：
        - WolfPeriodRange(start=period1, stop=period2)
        - WolfPeriodRange(period1, period2)
        - WolfPeriodRange(start=period1, count=10)
        """
        # 位置引数が提供された場合の処理
        if start is not None and 'start' not in kwargs:
            kwargs['start'] = start
        if stop is not None and 'stop' not in kwargs:
            kwargs['stop'] = stop
        
        # キーワード引数を統合
        kwargs.update({
            'step': step,
            'count': count
        })
        
        super().__init__(**kwargs)

    # ---------- プロパティ ----------
    @computed_field
    @property
    def freq(self) -> Frequency:
        """範囲の頻度。開始期間から導出されます。"""
        return self.start.freq

    # ---------- コアイテレーション ----------
    def __iter__(self) -> Iterator["WolfPeriod"]:
        """期間範囲をイテレートします。
        
        Yields
        ------
        WolfPeriod
            範囲内の各期間
        """
        if self.count is not None:
            # 期間数が指定されている場合
            cur = self.start
            for _ in range(self.count):
                yield cur
                cur = cur + self.step
            return

        if self.stop is None:
            raise ValueError("`stop` または `count` のいずれかを指定してください")

        # 開始から終了までイテレート
        cur = self.start
        if self.step > 0:
            # 正のステップ（昇順）
            while cur <= self.stop:
                yield cur
                cur = cur + self.step
        else:
            # 負のステップ（降順）
            while cur >= self.stop:
                yield cur
                cur = cur + self.step

    def to_list(self) -> list["WolfPeriod"]:
        """期間範囲をリストに変換します。
        
        Returns
        -------
        list[WolfPeriod]
            期間のリスト
        """
        return list(iter(self))

    def labels(self) -> list[str]:
        """期間範囲のラベルリストを返します。
        
        Returns
        -------
        list[str]
            期間ラベルのリスト
        """
        return [p.label for p in self]

    def __len__(self) -> int:
        """期間範囲の長さを返します。
        
        Returns
        -------
        int
            期間範囲の長さ
        
        Raises
        ------
        ValueError
            無制限の範囲の場合
        """
        if self.count is not None:
            return self.count
        if self.stop is None:
            raise ValueError("無制限の範囲に対しては len() は定義されていません")
        diff = self.stop - self.start
        step = abs(self.step)
        # 包含的範囲の長さ（差分がステップの倍数でなくても）
        return diff // step + 1

    # ---------- インデックス / スライス ----------
    @overload
    def __getitem__(self, idx: int) -> "WolfPeriod": ...
    @overload
    def __getitem__(self, idx: slice) -> "WolfPeriodRange": ...

    def __getitem__(self, idx):
        """インデックスまたはスライスによるアクセスを提供します。
        
        Parameters
        ----------
        idx : int | slice
            インデックスまたはスライス
        
        Returns
        -------
        WolfPeriod | WolfPeriodRange
            単一の期間または新しい範囲
        
        Raises
        ------
        IndexError
            インデックスが範囲外の場合
        TypeError
            サポートされていないインデックス型
        """
        if isinstance(idx, int):
            # 単一インデックスアクセス
            if idx < 0:
                idx = len(self) + idx
            if idx < 0 or idx >= len(self):
                raise IndexError("指定されたインデックスが範囲外です")
            return (self.start + (idx * self.step))
        if isinstance(idx, slice):
            # スライスアクセス
            start = idx.start or 0
            stop = idx.stop if idx.stop is not None else len(self)
            step = idx.step or 1
            if start < 0 or stop < 0:
                # 負のインデックスを長さに基づいて正に変換
                L = len(self)
                if start < 0: start = L + start
                if stop < 0: stop = L + stop
            new_start = self[start]
            new_count = max(0, stop - start)
            new_step = self.step * step
            return WolfPeriodRange(start=new_start, count=new_count, step=new_step)
        raise TypeError("インデックスは int または slice である必要があります")
    
    def __contains__(self, item: Any) -> bool:
        """与えられたオブジェクトがこの期間範囲に含まれるか判定します。
        
        Parameters
        ----------
        item : Any
            判定対象のオブジェクト。以下の型をサポート：
            - WolfPeriod（同一モード：freq / week_start / fy_start_month）
            - datetime.date / datetime.datetime
            - pandas.Timestamp
        
        Returns
        -------
        bool
            オブジェクトが範囲に含まれる場合True、そうでなければFalse
        
        Raises
        ------
        ValueError
            モードが異なるWolfPeriodが渡された場合
        TypeError
            未対応の型が渡された場合
        """
        # 小さなヘルパー：現在の範囲モードで date を WolfPeriod に変換
        def _convert_date_like(d: date) -> WolfPeriod:
            f = self.freq
            # 週開始日と会計年度開始月は開始期間に合わせる
            week_start = self.start.week_start
            fy_start = self.start.fy_start_month

            if f is Frequency.D:
                return WolfPeriod.from_day(d)
            if f is Frequency.W:
                return WolfPeriod.from_week(d, week_start=week_start)
            if f is Frequency.M:
                return WolfPeriod.from_month(d.year, d.month)
            if f is Frequency.Q:
                # 会計年度ラベルと四半期を計算
                fy_label = d.year if d.month >= fy_start else d.year - 1
                # 会計年度内の1-12月インデックスを求め、四半期へ
                month_in_fy = ((d.month - fy_start) % 12) + 1
                q = (month_in_fy - 1) // 3 + 1
                return WolfPeriod.from_quarter(fy_label, q, fy_start_month=fy_start)
            if f is Frequency.Y:
                fy_label = d.year if d.month >= fy_start else d.year - 1
                return WolfPeriod(freq=Frequency.Y, y=fy_label, fy_start_month=fy_start)
            raise ValueError("未知の頻度です")

        # 内部ヘルパー：実際の包含判定（同一モードが前提）
        def _contains_same_mode(target: WolfPeriod) -> bool:
            s = self.start.ordinal
            e = self.stop.ordinal
            t = target.ordinal
            if self.step > 0:
                if not (s <= t <= e):
                    return False
                return (t - s) % self.step == 0
            else:
                if not (e <= t <= s):
                    return False
                return (s - t) % (-self.step) == 0

        # 1) WolfPeriod
        if isinstance(item, WolfPeriod):
            # モード（freq / week_start / fy_start_month）が違う場合は誤用として例外
            if item._mode_key() != self.start._mode_key():
                raise ValueError(
                    "互換性のないモードのWolfPeriodが渡されました。"
                    f"渡されたモード={item._mode_key()} / 範囲のモード={self.start._mode_key()}"
                )
            return _contains_same_mode(item)

        # 2) datetime.date / datetime.datetime
        if isinstance(item, datetime):
            item = item.date()
        if isinstance(item, date):
            return _contains_same_mode(_convert_date_like(item))

        # 3) pandas.Timestamp
        if isinstance(item, pd.Timestamp):
            return _contains_same_mode(_convert_date_like(item.to_pydatetime().date()))

        # 未対応の型はTypeError
        raise TypeError(
            f"範囲の包含判定に対応していない型です: {type(item).__name__}。"
            "以下のいずれかの型を指定してください："
            "・WolfPeriod"
            "・datetime.date"
            "・datetime.datetime"
            "・pandas.Timestamp"
        )

    # ---------- 便利なメソッド ----------
    def to_index(self) -> pd.Index:
        """pandas Indexのラベルを返します（表示用に安全）。
        
        Returns
        -------
        pd.Index
            期間ラベルのpandas Index
        """
        return pd.Index(self.labels(), name=str(self.start.freq.value))

    # ---------- 表示 ----------
    def info(self) -> str:
        """人間に読みやすい範囲の概要を返します。
        
        Returns
        -------
        str
            範囲の概要文字列
        """
        # 1) 頻度（日本語名）
        freq_map = {
            Frequency.D: "日次",
            Frequency.W: "週次",
            Frequency.M: "月次",
            Frequency.Q: "四半期",
            Frequency.Y: "年次",
        }
        freq_ja = freq_map.get(self.start.freq, self.start.freq.name)

        # 2) ステップ（単位付き、符号つき）
        unit_map = {
            Frequency.D: "日",
            Frequency.W: "週",
            Frequency.M: "月",
            Frequency.Q: "四半期",
            Frequency.Y: "年",
        }
        step_sign = "+" if self.step > 0 else "-"
        step_abs = abs(self.step)
        step_unit = unit_map.get(self.start.freq, "")
        step_disp = f"{step_sign}{step_abs}{step_unit}"

        # 3) 並び方向
        direction = "昇順" if self.step > 0 else "降順"

        # 4) 実際の終端（最後に生成される要素）
        last_label: str | None = None
        stop_label: str | None = None
        try:
            if self.count is not None:
                last = self.start + (self.step * (self.count - 1))
                last_label = last.label
            elif self.stop is not None:
                # 空範囲判定（開始と終了がステップ方向に不整合）
                if (self.step > 0 and self.start > self.stop) or (self.step < 0 and self.start < self.stop):
                    last_label = "{}"
                    stop_label = self.stop.label
                else:
                    # stopに完全一致しない場合でも、実際に得られる最後の要素を計算
                    diff = abs(self.stop - self.start)
                    steps = diff // abs(self.step)
                    last = self.start + (self.step * steps)
                    last_label = last.label
                    stop_label = self.stop.label
            else:
                last_label = None
        except Exception:
            last_label = None

        # 5) 長さ
        try:
            if last_label == "{}":
                n_disp = "0"
            else:
                n = len(self)
                n_disp = str(n)
        except Exception:
            n_disp = "?"

        # 6) モード詳細（週開始/会計年度開始）
        extras: list[str] = []
        if self.start.freq is Frequency.W:
            extras.append(f"週開始={self.start.week_start.name.title()}")
        if self.start.freq in (Frequency.Q, Frequency.Y):
            extras.append(f"会計年度開始={self.start.fy_start_month:02d}月")

        # count/stop モードの明示
        if self.count is not None:
            extras.append(f"生成数={self.count}")
        if stop_label is not None and last_label is not None and last_label != stop_label:
            # stop 指定と実終端が異なる場合は補足を表示
            extras.append(f"終端指定={stop_label}")

        # 7) pandas エイリアス
        try:
            import calendar as _cal
            f = self.start.freq
            if f is Frequency.D:
                pd_alias = "D"
            elif f is Frequency.W:
                pd_alias = f"W-{self.start.week_start.name[:3]}"
            elif f is Frequency.M:
                pd_alias = "M"
            elif f is Frequency.Q:
                end_month = ((self.start.fy_start_month - 2) % 12) + 1
                pd_alias = f"Q-{_cal.month_abbr[end_month].upper()}"
            elif f is Frequency.Y:
                end_month = ((self.start.fy_start_month - 2) % 12) + 1
                pd_alias = f"A-{_cal.month_abbr[end_month].upper()}"
            else:
                pd_alias = self.start.freq.value
            extras.append(f"pandas={pd_alias}")
        except Exception:
            pass

        first = self.start.label
        last_part = last_label if last_label is not None else "?"
        extras_part = (", " + ", ".join(extras)) if extras else ""
        return f"{freq_ja}範囲: {first} → {last_part} [{direction}] (ステップ={step_disp}, 長さ={n_disp}){extras_part}"

    def __repr__(self) -> str:
        """開発者向けの文字列表現を返します。"""
        return f"WolfPeriodRange(start={self.start}, stop={self.stop}, step={self.step}, count={self.count})"
