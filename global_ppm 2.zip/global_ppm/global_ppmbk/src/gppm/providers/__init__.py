"""
データプロバイダーモジュール
============================

目的
- 外部データソース（FactSet、CIQ、RBICS等）からのデータ取得を統合管理
- 企業識別子・財務データ・セクター分類への統一インターフェースを提供
- 各データソースの特性を活かした最適化されたデータ取得

主要コンポーネント
- FactSetProvider: FactSet企業識別子・財務データの統合取得
- CIQProvider: CIQ企業識別子データの取得（財務データは将来実装予定）
- RBICSProvider: FactSet REVERE RBICSセクター分類データの取得

使用例:
    from gppm.providers import FactSetProvider, CIQProvider, RBICSProvider
    
    # FactSetから企業識別子・財務データを取得
    fs_provider = FactSetProvider()
    identity_records = fs_provider.get_identity_records()
    financial_records = fs_provider.get_financial_records()
    
    # CIQから企業識別子を取得
    ciq_provider = CIQProvider()
    ciq_records = ciq_provider.get_identity_records()
    # ciq_financial = ciq_provider.get_financial_records()  # 将来実装予定
    
    # RBICSから企業セクター分類を取得
    rbics_provider = RBICSProvider()
    structure_records = rbics_provider.get_structure_records()
    company_records = rbics_provider.get_company_records()
"""

from gppm.providers.factset_provider import (
    FactSetProvider,
    FactSetIdentityRecord,
    FactSetFinancialRecord,
    FactSetQueryParams,
)
from gppm.providers.ciq_provider import (
    CIQProvider,
    CIQIdentityRecord,
    CIQFinancialRecord,
    CIQQueryParams,
)
from gppm.providers.rbics_provider import (
    RBICSProvider,
)
from gppm.providers.rbics_types import (
    RBICSStructureRecord,
    RBICSCompanyRecord,
    RBICSQueryParams,
    SegmentType,
    RBICSLevel,
)

__all__ = [
    "FactSetProvider",
    "FactSetIdentityRecord",
    "FactSetFinancialRecord",
    "FactSetQueryParams",
    "CIQProvider", 
    "CIQIdentityRecord",
    "CIQFinancialRecord",
    "CIQQueryParams",
    "RBICSProvider",
    "RBICSStructureRecord",
    "RBICSCompanyRecord",
    "RBICSQueryParams",
    "SegmentType",
    "RBICSLevel",
]
