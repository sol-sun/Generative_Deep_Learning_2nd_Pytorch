"""
WolfPeriod型システム: 期間処理の基盤となる型定義

概要
-----
WolfPeriodライブラリの型安全性と一貫性を保証するため、期間処理に必要な
基本的な型定義とユーティリティを提供します。金融・ビジネス分析における
期間の概念を型レベルで表現し、コンパイル時エラーを最小化します。

型定義
------
• Frequency: 期間頻度の列挙型（D/W/M/Q/Y）
• Weekday: 曜日表現（週開始日設定用）
• QuarterIndex: 四半期インデックス（Q1-Q4）- 統合された型変換機能付き
• CalendarConfig: カレンダー設定管理クラス

使用例
------
>>> from .types import Frequency, Weekday, QuarterIndex
>>> freq = Frequency.M  # 月次
>>> wd = Weekday.MON    # 月曜日開始
>>> q = QuarterIndex("Q1")  # 第1四半期
>>> config = CalendarConfig(week_start=wd, fy_start_month=4)
"""

from enum import Enum
from pydantic import BaseModel, ConfigDict, Field
from typing import Annotated

class Frequency(str, Enum):
    """期間の頻度を表す列挙型。
    
    金融・ビジネス分析で使用される標準的な期間単位を定義します。
    """
    D = "D"   # 日次 (Daily)
    W = "W"   # 週次 (Weekly)
    M = "M"   # 月次 (Monthly)
    Q = "Q"   # 四半期 (Quarterly - 会計年度開始に合わせた四半期)
    Y = "Y"   # 年次 (Yearly - 会計年度)

    # 読みやすい別名（エイリアス）
    DAILY = "D"      # 日次
    WEEKLY = "W"     # 週次
    MONTHLY = "M"    # 月次
    QUARTERLY = "Q"  # 四半期
    YEARLY = "Y"     # 年次

    def __new__(cls, value):
        """様々な形式の入力からFrequencyオブジェクトを作成します。
        
        Parameters
        ----------
        value : str | Frequency
            頻度の指定。以下の形式がサポートされます：
            - 文字列: "D", "W", "M", "Q", "Y"
            - Frequency: 既存のFrequencyオブジェクト
        
        Returns
        -------
        Frequency
            正規化された頻度オブジェクト
        
        Raises
        ------
        ValueError
            無効な頻度が指定された場合
        """
        if isinstance(value, cls):
            return value
        
        if isinstance(value, str):
            # 文字列を大文字に変換
            value_clean = value.strip().upper()
            try:
                return super().__new__(cls, value_clean)
            except ValueError:
                valid_values = ", ".join([f"'{f.value}'" for f in cls])
                raise ValueError(f"無効な頻度: '{value}'。有効な値: {valid_values}")
        else:
            raise TypeError(f"サポートされていない型: {type(value).__name__}。str, Frequencyのいずれかを指定してください")

class Weekday(int, Enum):
    """曜日を表す列挙型。
    
    Pythonの標準的な曜日表現（月曜日=0, 日曜日=6）に準拠しています。
    """
    MON = 0  # 月曜日
    TUE = 1  # 火曜日
    WED = 2  # 水曜日
    THU = 3  # 木曜日
    FRI = 4  # 金曜日
    SAT = 5  # 土曜日
    SUN = 6  # 日曜日

    def __str__(self) -> str:
        """曜日の名前をタイトルケースで返します（例: 'Mon', 'Tue'）"""
        return self.name.title()

class QuarterIndex(int, Enum):
    """四半期インデックスを表す列挙型。
    
    会計年度内の四半期を1-4のインデックスで表現します。
    様々な形式の入力からQuarterIndexオブジェクトを作成できます。
    
    Examples
    --------
    >>> QuarterIndex(1)           # QuarterIndex.Q1
    >>> QuarterIndex("Q2")        # QuarterIndex.Q2
    >>> QuarterIndex("3")         # QuarterIndex.Q3
    >>> QuarterIndex(QuarterIndex.Q4)  # QuarterIndex.Q4

    """
    Q1 = 1  # 第1四半期
    Q2 = 2  # 第2四半期
    Q3 = 3  # 第3四半期
    Q4 = 4  # 第4四半期

    def __new__(cls, value):
        """様々な形式の入力からQuarterIndexオブジェクトを作成します。
        
        Parameters
        ----------
        value : int | str | QuarterIndex
            四半期の指定。以下の形式がサポートされます：
            - 整数: 1, 2, 3, 4
            - 文字列: "1", "2", "3", "4", "Q1", "Q2", "Q3", "Q4"
            - QuarterIndex: 既存のQuarterIndexオブジェクト
        
        Returns
        -------
        QuarterIndex
            正規化された四半期インデックス
        
        Raises
        ------
        ValueError
            四半期インデックスが1-4の範囲外の場合
        TypeError
            サポートされていない型が指定された場合
        
        """
        if isinstance(value, cls):
            return value
        
        if isinstance(value, str):
            # 文字列から"Q"プレフィックスを除去し、大文字に変換
            value_clean = value.strip().upper().lstrip("Q")
            try:
                qi = int(value_clean)
            except ValueError:
                raise ValueError(f"無効な四半期文字列: '{value}'。有効な形式: 1-4, 'Q1'-'Q4', '1'-'4'")
        
        elif isinstance(value, int):
            qi = value
        else:
            raise TypeError(f"サポートされていない型: {type(value).__name__}。int, str, QuarterIndexのいずれかを指定してください")
        
        if not (1 <= qi <= 4):
            raise ValueError(f"四半期インデックスは1-4の範囲である必要があります。指定された値: {qi}")
        
        return super().__new__(cls, qi)

    def __str__(self) -> str:
        """四半期の名前を返します（例: 'Q1', 'Q2'）"""
        return f"Q{self.value}"

class CalendarConfig(BaseModel):
    """カレンダー設定を管理するクラス。
    
    週の開始日と会計年度の開始月を設定し、期間計算全体で一貫した
    カレンダー設定を提供します。
    
    Attributes
    ----------
    week_start : Weekday
        週の開始日（デフォルト: 月曜日）
    fy_start_month : int
        会計年度の開始月（デフォルト: 4月）
    """
    model_config = ConfigDict(frozen=True)  # イミュータブル設定

    week_start: Weekday = Field(
        default=Weekday.MON, 
        description="週の開始日（デフォルト: 月曜日）"
    )
    fy_start_month: int = Field(
        default=4, 
        ge=1, 
        le=12, 
        description="会計年度の開始月（1-12の範囲、デフォルト: 4月）"
    )

    def with_week_start(self, wd: Weekday) -> "CalendarConfig":
        """週開始日を変更した新しい設定を返します。
        
        Parameters
        ----------
        wd : Weekday
            新しい週開始日
        
        Returns
        -------
        CalendarConfig
            週開始日が変更された新しい設定
        """
        return CalendarConfig(week_start=wd, fy_start_month=self.fy_start_month)

    def with_fy_start(self, m: int) -> "CalendarConfig":
        """会計年度開始月を変更した新しい設定を返します。
        
        Parameters
        ----------
        m : int
            新しい会計年度開始月（1-12）
        
        Returns
        -------
        CalendarConfig
            会計年度開始月が変更された新しい設定
        """
        return CalendarConfig(week_start=self.week_start, fy_start_month=m)


class YearMonth(BaseModel):
    """年月を表すイミュータブルな値オブジェクト。

    主に `YYYYMM` 形式の受け取りと検証を担当し、`WolfPeriod.from_yyyymm()`
    の入力検証に用いられます。

    Examples
    --------
    >>> YearMonth.from_yyyymm(202404)
    YearMonth(y=2024, m=4)
    >>> YearMonth.from_yyyymm("2024-04")
    YearMonth(y=2024, m=4)
    >>> YearMonth.from_yyyymm("202404").yyyymm
    202404
    """

    model_config = ConfigDict(frozen=True)

    y: int = Field(description="年（例: 2024）", ge=1970, examples=[2024])
    m: int = Field(description="月（1-12）", ge=1, le=12, examples=[4])

    @classmethod
    def from_yyyymm(cls, value: int | str) -> "YearMonth":
        """`YYYYMM` または `YYYY-MM` から `YearMonth` を生成します。

        Parameters
        ----------
        value : int | str
            `202404` のような6桁整数／文字列、または `2024-04` のような表記。

        Returns
        -------
        YearMonth
            検証済みの年月オブジェクト

        Raises
        ------
        ValueError
            フォーマットが不正、または月が1-12の範囲外の場合
        TypeError
            サポートされない型が渡された場合
        """
        if isinstance(value, int):
            s = f"{value:06d}"
        elif isinstance(value, str):
            s = value.strip()
            if len(s) == 7 and s[4] == "-":
                s = s.replace("-", "")
        else:
            raise TypeError(
                f"YearMonthはintまたはstrを受け取ります。受領型: {type(value).__name__}"
            )

        if not (len(s) == 6 and s.isdigit()):
            raise ValueError(
                "YYYYMM形式（例: 202404）またはYYYY-MM形式（例: 2024-04）で指定してください"
            )

        year = int(s[:4])
        if not (1970 <= year):
            raise ValueError(f"年は1970〜の範囲である必要があります。指定値: {year}")

        month = int(s[4:])
        if not (1 <= month <= 12):
            raise ValueError(f"月は1-12の範囲である必要があります。指定値: {month}")
        
        return cls(y=year, m=month)

    @property
    def yyyymm(self) -> int:
        """`YYYYMM` の整数表現を返します。"""
        return self.y * 100 + self.m

    def __str__(self) -> str:
        return f"{self.y:04d}-{self.m:02d}"
