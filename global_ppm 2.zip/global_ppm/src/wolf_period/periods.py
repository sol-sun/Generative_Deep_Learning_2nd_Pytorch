"""
WolfPeriod: 金融・ビジネス分析特化の期間操作クラス

概要
-----
金融・ビジネス分析における期間処理の複雑性を解決するため、D/W/M/Q/Y（日/週/月/四半期/年）
に特化した期間操作クラスを提供します。会計年度や週開始日の柔軟な設定に対応した
直感的なAPIを実現します。

主要機能
--------
• 期間表現: 日次/週次/月次/四半期/年次（会計年度対応）
• 期間演算: 加算・減算・差分計算（型安全）
• 期間変換: pandas Periodとの相互変換
• 期間情報: 開始日・終了日
• シリアライゼーション: 辞書形式での保存・復元

使用例
------
>>> from datetime import date
>>> p1 = WolfPeriod.from_day(date(2024, 1, 15))
>>> p2 = WolfPeriod.from_quarter(2024, 1, fy_start_month=4)
>>> p3 = p1 + 30  # 30日後
>>> m1 = WolfPeriod.from_yyyymm(202404)  # 2024年4月
>>> m2 = WolfPeriod.from_yyyymm("2024-04")  # 2024年4月（ハイフン形式）
"""

from datetime import date, timedelta
import calendar
from typing import Optional, Tuple, Dict, Any, Union

from pydantic import BaseModel, ConfigDict, computed_field, field_validator, model_validator

from .types import (
    Frequency,
    Weekday,
    CalendarConfig,
    QuarterIndex,
    YearMonth,
)

# ---------- ヘルパー関数 ----------
def _first_day_of_month(y: int, m: int) -> date:
    """指定された年月の最初の日を返します。"""
    return date(y, m, 1)

def _last_day_of_month(y: int, m: int) -> date:
    """指定された年月の最後の日を返します。"""
    import calendar as _cal
    last = _cal.monthrange(y, m)[1]
    return date(y, m, last)

def _week_start_for(d: date, week_start: Weekday) -> date:
    """指定された日付が属する週の開始日を返します。
    
    Parameters
    ----------
    d : date
        基準となる日付
    week_start : Weekday
        週の開始日（例: Weekday.MONで月曜日開始）
    
    Returns
    -------
    date
        週の開始日
    """
    target = int(week_start.value)  # 0=月曜日..6=日曜日
    dow = d.weekday()
    delta = (dow - target) % 7
    return d - timedelta(days=delta)

def _week_end_for(d: date, week_start: Weekday) -> date:
    """指定された日付が属する週の終了日を返します。"""
    s = _week_start_for(d, week_start)
    return s + timedelta(days=6)

def _fy_anchor(year_label: int, fy_start_month: int) -> tuple[date, date]:
    """会計年度の開始日と終了日を返します。
    
    Parameters
    ----------
    year_label : int
        会計年度のラベル（例: 2025）
    fy_start_month : int
        会計年度の開始月（例: 4月）
    
    Returns
    -------
    tuple[date, date]
        (開始日, 終了日)のタプル
        
    Example
    -------
    fy_start_month=4（4月）の場合、FY2025は2025-04-01..2026-03-31をカバー
    """
    # 第1四半期は会計年度開始月から始まる
    start = date(year_label, fy_start_month, 1)
    next_start = date(year_label + 1, fy_start_month, 1)
    end = next_start - timedelta(days=1)
    return start, end

def _fy_quarter_start_end(fy_label: int, q: QuarterIndex, fy_start_month: int) -> tuple[date, date]:
    """会計年度内の四半期の開始日と終了日を返します。
    
    Parameters
    ----------
    fy_label : int
        会計年度のラベル
    q : QuarterIndex
        四半期インデックス（1-4）
    fy_start_month : int
        会計年度の開始月
    
    Returns
    -------
    tuple[date, date]
        (四半期開始日, 四半期終了日)のタプル
    """
    # 第1四半期は会計年度開始月から始まる
    start_month = ((fy_start_month - 1) + (int(q) - 1) * 3) % 12 + 1
    start_year = fy_label if start_month >= fy_start_month else fy_label + 1
    start = date(start_year, start_month, 1)
    
    # 次の四半期の開始日を計算
    nq = (int(q) % 4) + 1
    n_start_month = ((fy_start_month - 1) + (nq - 1) * 3) % 12 + 1
    n_start_year = fy_label if n_start_month >= fy_start_month else fy_label + 1
    next_start = date(n_start_year, n_start_month, 1)
    end = next_start - timedelta(days=1)
    return start, end

class WolfPeriod(BaseModel):
    """期間オブジェクト．

    金融・ビジネス分析に特化した期間表現を提供します。

    Attributes
    ----------
    freq : Frequency
        頻度（D/W/M/Q/Yのいずれか）
    y : int
        年ラベル（D/W/Mの場合は年、Q/Yの場合は会計年度ラベル）
    m : Optional[int]
        月次の場合の月、または日次の場合のカレンダー月（from_dayで構築時）
    d : Optional[int]
        月の日（日次の場合のみ）
    week_start : Weekday
        週の開始日（freq == Wの場合のみ使用）。文字列/ラベルで常に明示
    fy_start_month : int
        会計年度開始月（Q/Yで使用）。文字列/ラベルで常に明示
    q : Optional[QuarterIndex]
        四半期インデックス1-4（freq == Qの場合のみ使用）
    """
    model_config = ConfigDict(frozen=True)  # イミュータブル設定

    freq: Frequency
    y: int
    m: Optional[int] = None
    d: Optional[int] = None
    week_start: Weekday = Weekday.MON
    fy_start_month: int = 4
    q: Optional[QuarterIndex] = None

    # ---------- フィールドレベル検証 ----------
    @field_validator("fy_start_month")
    @classmethod
    def _check_fy_month(cls, v: int) -> int:
        """会計年度開始月の妥当性をチェックします。"""
        if not (1 <= v <= 12):
            raise ValueError("会計年度開始月は1-12の範囲である必要があります")
        return v

    @field_validator("m")
    @classmethod
    def _check_month(cls, v: Optional[int]) -> Optional[int]:
        """月の妥当性をチェックします。"""
        if v is None:
            return v
        if not (1 <= v <= 12):
            raise ValueError("月は1-12の範囲である必要があります")
        return v

    @field_validator("d")
    @classmethod
    def _check_day(cls, v: Optional[int]) -> Optional[int]:
        """日の妥当性をチェックします。"""
        if v is None:
            return v
        if not (1 <= v <= 31):
            raise ValueError("日は1-31の範囲である必要があります")
        return v

    # ---------- 複数フィールドをまたぐ検証 ----------
    @model_validator(mode="after")
    def _validate_combo(self):
        """頻度とフィールドの組み合わせの妥当性を検証します。"""
        match self.freq:
            case Frequency.D:
                if self.m is None or self.d is None:
                    raise ValueError("日次には月と日が必要です")
                if self.q is not None:
                    raise ValueError("日次では四半期qを設定できません")
            case Frequency.W:
                if self.m is None or self.d is None:
                    raise ValueError("週次には週の開始日から計算される基準日（年・月・日）が必要です")
                if self.q is not None:
                    raise ValueError("週次では四半期qを設定できません")
            case Frequency.M:
                if self.m is None:
                    raise ValueError("月次には月が必要です")
                if self.d is not None or self.q is not None:
                    raise ValueError("月次では日dや四半期qを設定できません")
            case Frequency.Q:
                if self.q is None:
                    raise ValueError("四半期にはqが必要です")
                if self.m is not None or self.d is not None:
                    raise ValueError("四半期では月mや日dを設定できません")
            case Frequency.Y:
                if self.m is not None or self.d is not None or self.q is not None:
                    raise ValueError("年次（会計年度）では月m、日d、四半期qを設定できません")
        return self

    # -------- コンストラクタ --------
    @staticmethod
    def from_day(d: date, *, freq: Optional[Frequency] = None, week_start: Weekday = Weekday.MON, fy_start_month: int = 4) -> "WolfPeriod":
        """日付から指定された頻度のWolfPeriodを作成します。
        
        Parameters
        ----------
        d : date
            基準となる日付
        freq : Optional[Frequency]
            生成したい頻度（デフォルトはNoneで日次）。
            Yを指定した場合は会計年度（freq=Y）を返します。
        week_start : Weekday
            週次へ変換する場合の週開始日（未使用時は無視）
        fy_start_month : int
            年次・四半期へ変換する場合の会計年度開始月（未使用時は無視）
        
        Returns
        -------
        WolfPeriod
            指定された頻度の期間オブジェクト
        """
        # デフォルトは日次
        if freq is None:
            return WolfPeriod(freq=Frequency.D, y=d.year, m=d.month, d=d.day)
        
        match freq:
            case Frequency.D:
                return WolfPeriod(freq=Frequency.D, y=d.year, m=d.month, d=d.day)
            case Frequency.Y:
                fy_label = d.year if d.month >= fy_start_month else d.year - 1
                return WolfPeriod(freq=Frequency.Y, y=fy_label, fy_start_month=fy_start_month)
            case Frequency.W:
                anchor = _week_start_for(d, week_start)
                return WolfPeriod(freq=Frequency.W, y=anchor.year, m=anchor.month, d=anchor.day, week_start=week_start)
            case Frequency.M:
                return WolfPeriod(freq=Frequency.M, y=d.year, m=d.month)
            case Frequency.Q:
                # 会計年度ラベルと四半期を算出
                fy_label = d.year if d.month >= fy_start_month else d.year - 1
                month_in_fy = ((d.month - fy_start_month) % 12) + 1
                q = QuarterIndex((month_in_fy - 1) // 3 + 1)
                return WolfPeriod(freq=Frequency.Q, y=fy_label, q=q, fy_start_month=fy_start_month)
            case _:
                raise ValueError("未知の頻度が指定されました")

    @staticmethod
    def from_week(any_day_in_week: date, week_start: Weekday = Weekday.MON) -> "WolfPeriod":
        """週内の任意の日から週次のWolfPeriodを作成します。
        
        Parameters
        ----------
        any_day_in_week : date
            週内の任意の日付
        week_start : Weekday
            週の開始日（デフォルト: 月曜日）
        
        Returns
        -------
        WolfPeriod
            週次の期間オブジェクト
        """
        anchor = _week_start_for(any_day_in_week, week_start)
        return WolfPeriod(freq=Frequency.W, y=anchor.year, m=anchor.month, d=anchor.day, week_start=week_start)

    @staticmethod
    def from_month(y: int, m: int, *, freq: Frequency, fy_start_month: int = 4) -> "WolfPeriod":
        """年月から指定された頻度のWolfPeriodを作成します。
        
        Parameters
        ----------
        y : int
            年
        m : int
            月（1-12）
        freq : Frequency
            作成する期間の頻度（必須）
        fy_start_month : int
            会計年度開始月（Q/Yの場合に使用）
        
        Returns
        -------
        WolfPeriod
            指定された頻度の期間オブジェクト
        """
        match freq:
            case Frequency.M:
                return WolfPeriod(freq=Frequency.M, y=y, m=m)
            case Frequency.Q:
                # 月から会計年度と四半期を計算
                fy_label = y if m >= fy_start_month else y - 1
                month_in_fy = ((m - fy_start_month) % 12) + 1
                q = QuarterIndex((month_in_fy - 1) // 3 + 1)
                return WolfPeriod(freq=Frequency.Q, y=fy_label, q=q, fy_start_month=fy_start_month)
            case Frequency.Y:
                fy_label = y if m >= fy_start_month else y - 1
                return WolfPeriod(freq=Frequency.Y, y=fy_label, fy_start_month=fy_start_month)
            case _:
                raise ValueError(f"from_monthでは頻度{freq}はサポートされていません。M/Q/Yのみサポートしています。")

    @staticmethod
    def from_yyyymm(yyyymm: int | str, *, freq: Frequency, fy_start_month: int = 4) -> "WolfPeriod":
        """`YYYYMM` または `YYYY-MM` から指定された頻度のWolfPeriodを作成します。
        
        Parameters
        ----------
        yyyymm : int | str
            `202404` や `"202404"`、`"2024-04"` のような表記。
        freq : Frequency
            作成する期間の頻度（必須）
        fy_start_month : int
            会計年度開始月（Q/Yの場合に使用）
        
        Returns
        -------
        WolfPeriod
            指定された頻度の期間オブジェクト
        
        Raises
        ------
        ValidationError
            フォーマット不正や月範囲外の場合（`YearMonth` により検証）
        """
        ym = YearMonth.from_yyyymm(yyyymm)
        return WolfPeriod.from_month(ym.y, ym.m, freq=freq, fy_start_month=fy_start_month)

    @staticmethod
    def from_quarter(fy_label: int, q: Union[int, QuarterIndex], fy_start_month: int = 4) -> "WolfPeriod":
        """会計年度と四半期から四半期のWolfPeriodを作成します。
        
        Parameters
        ----------
        fy_label : int
            会計年度ラベル
        q : int | QuarterIndex
            四半期インデックス（1-4）
        fy_start_month : int
            会計年度開始月（デフォルト: 4月）
        
        Returns
        -------
        WolfPeriod
            四半期の期間オブジェクト
        """
        qi = QuarterIndex(q)
        return WolfPeriod(freq=Frequency.Q, y=fy_label, q=qi, fy_start_month=fy_start_month)

    # -------- コアプロパティ --------
    @property
    def value(self) -> None:
        """常にNoneを返します。"""
        return None

    @computed_field
    @property
    def start_date(self) -> date:
        """期間の開始日を返します。"""
        match self.freq:
            case Frequency.D:
                return date(self.y, self.m or 1, self.d or 1)
            case Frequency.W:
                return _week_start_for(date(self.y, self.m or 1, self.d or 1), self.week_start)
            case Frequency.M:
                return _first_day_of_month(self.y, self.m or 1)
            case Frequency.Q:
                s, _ = _fy_quarter_start_end(self.y, self.q or QuarterIndex.Q1, self.fy_start_month)
                return s
            case Frequency.Y:
                s, _ = _fy_anchor(self.y, self.fy_start_month)
                return s
            case _:
                raise ValueError("サポートされていない頻度")

    @computed_field
    @property
    def end_date(self) -> date:
        """期間の終了日を返します。"""
        match self.freq:
            case Frequency.D:
                return date(self.y, self.m or 1, self.d or 1)
            case Frequency.W:
                return _week_end_for(date(self.y, self.m or 1, self.d or 1), self.week_start)
            case Frequency.M:
                return _last_day_of_month(self.y, self.m or 1)
            case Frequency.Q:
                _, e = _fy_quarter_start_end(self.y, self.q or QuarterIndex.Q1, self.fy_start_month)
                return e
            case Frequency.Y:
                _, e = _fy_anchor(self.y, self.fy_start_month)
                return e
            case _:
                raise ValueError("サポートされていない頻度")

    @computed_field
    @property
    def label(self) -> str:
        """人間に読みやすい期間ラベルを返します。
        
        設定（週開始日、会計年度開始月）が埋め込まれています。
        """
        match self.freq:
            case Frequency.D:
                return f"{self.start_date:%Y-%m-%d}"
            case Frequency.W:
                wd = self.week_start.name.title()
                s = self.start_date
                return f"W[{wd}] {s:%Y-%m-%d}"
            case Frequency.M:
                return f"{self.y:04d}-{self.m:02d}"
            case Frequency.Q:
                return f"FY{self.y}-Q{int(self.q or 1)}(開始={self.fy_start_month:02d}月)"
            case Frequency.Y:
                return f"FY{self.y}(開始={self.fy_start_month:02d}月)"
            case _:
                raise ValueError("サポートされていない頻度")
    
    # -------- 年・会計年度アクセサ --------
    @computed_field
    @property
    def year(self) -> int:
        """暦年（開始日の年）を返します。freqに依らず `start_date.year` を返す。"""
        return self.start_date.year

    @computed_field
    @property
    def fiscal_year(self) -> int:
        """会計年度ラベルを返します。
        
        各頻度に応じて適切な会計年度を計算します：
        - 四半期/年次: `y` をそのまま返す
        - 月次: その月が属する会計年度を直接返す
        - 日/週次: 開始日に基づいて `fy_start_month` により算出
        """
        match self.freq:
            case Frequency.Q | Frequency.Y:
                return self.y
            case Frequency.M:
                # 月次はその月が属する会計年度を直接返す
                return self.y if self.m >= self.fy_start_month else (self.y - 1)
            case Frequency.D | Frequency.W:
                # 日/週次は開始日に基づいてFYを算出
                d = self.start_date
                return d.year if d.month >= self.fy_start_month else (d.year - 1)
            case _:
                raise ValueError("サポートされていない頻度")

    @computed_field
    @property
    def ordinal(self) -> int:
        """原点からの整数序数。週開始・会計年度設定と整合。"""
        epoch = date(1970, 1, 1)
        match self.freq:
            case Frequency.D:
                return (self.start_date - epoch).days
            case Frequency.W:
                base = _week_start_for(epoch, self.week_start)
                return (self.start_date - base).days // 7
            case Frequency.M:
                return (self.y * 12 + (self.m or 1)) - (1970 * 12 + 1)
            case Frequency.Q:
                a = self.y * 4 + (int(self.q or 1) - 1)
                b = 1970 * 4 + 0
                return a - b
            case Frequency.Y:
                return self.y - 1970
            case _:
                raise ValueError("サポートされていない頻度")

    # -------- 比較ヘルパー --------
    def _mode_key(self) -> tuple:
        """モード（頻度、週開始日、会計年度開始月）のキーを返します。"""
        return (self.freq, self.week_start, self.fy_start_month)

    def _ensure_same_mode(self, other: "WolfPeriod") -> None:
        """同じモードであることを確認します。"""
        if self._mode_key() != other._mode_key():
            raise ValueError(f"互換性のないモード: {self._mode_key()} vs {other._mode_key()}")

    # -------- 比較演算子 --------
    def __eq__(self, other: object) -> bool:
        """期間の等価性を判定します。
        
        Parameters
        ----------
        other : object
            比較対象のオブジェクト
        
        Returns
        -------
        bool
            等価な場合True、そうでなければFalse
        """
        if not isinstance(other, WolfPeriod):
            return NotImplemented
        self._ensure_same_mode(other)
        return self.ordinal == other.ordinal

    def __lt__(self, other: "WolfPeriod") -> bool:
        """期間の大小関係を判定します（小さい）。
        
        Parameters
        ----------
        other : WolfPeriod
            比較対象の期間
        
        Returns
        -------
        bool
            この期間がotherより小さい場合True
        
        Raises
        ------
        ValueError
            互換性のないモードの場合
        """
        if not isinstance(other, WolfPeriod):
            return NotImplemented
        self._ensure_same_mode(other)
        return self.ordinal < other.ordinal

    def __le__(self, other: "WolfPeriod") -> bool:
        """期間の大小関係を判定します（以下）。
        
        Parameters
        ----------
        other : WolfPeriod
            比較対象の期間
        
        Returns
        -------
        bool
            この期間がother以下の場合True
        
        Raises
        ------
        ValueError
            互換性のないモードの場合
        """
        if not isinstance(other, WolfPeriod):
            return NotImplemented
        self._ensure_same_mode(other)
        return self.ordinal <= other.ordinal

    def __gt__(self, other: "WolfPeriod") -> bool:
        """期間の大小関係を判定します（大きい）。
        
        Parameters
        ----------
        other : WolfPeriod
            比較対象の期間
        
        Returns
        -------
        bool
            この期間がotherより大きい場合True
        
        Raises
        ------
        ValueError
            互換性のないモードの場合
        """
        if not isinstance(other, WolfPeriod):
            return NotImplemented
        self._ensure_same_mode(other)
        return self.ordinal > other.ordinal

    def __ge__(self, other: "WolfPeriod") -> bool:
        """期間の大小関係を判定します（以上）。
        
        Parameters
        ----------
        other : WolfPeriod
            比較対象の期間
        
        Returns
        -------
        bool
            この期間がother以上の場合True
        
        Raises
        ------
        ValueError
            互換性のないモードの場合
        """
        if not isinstance(other, WolfPeriod):
            return NotImplemented
        self._ensure_same_mode(other)
        return self.ordinal >= other.ordinal

    # -------- 算術演算 --------
    def __add__(self, n: int) -> "WolfPeriod":
        """期間に整数を加算して新しい期間を返します。
        
        Parameters
        ----------
        n : int
            加算する期間数
        
        Returns
        -------
        WolfPeriod
            新しい期間オブジェクト
        
        Raises
        ------
        TypeError
            整数以外が指定された場合
        """
        if not isinstance(n, int):
            raise TypeError("整数（期間数）のみ加算できます")
        if n == 0:
            return self

        match self.freq:
            case Frequency.D:
                s = self.start_date + timedelta(days=n)
                return WolfPeriod.from_day(s)
            case Frequency.W:
                s = self.start_date + timedelta(days=7 * n)
                return WolfPeriod.from_week(s, self.week_start)
            case Frequency.M:
                y, m = self.y, self.m or 1
                total = (y * 12 + (m - 1)) + n
                ny, nm = divmod(total, 12)
                return WolfPeriod.from_month(ny, nm + 1, freq=Frequency.M)
            case Frequency.Q:
                qi = int(self.q or 1)
                new_index = qi - 1 + n
                new_fy = self.y + new_index // 4
                new_q = (new_index % 4) + 1
                return WolfPeriod.from_quarter(new_fy, new_q, self.fy_start_month)
            case Frequency.Y:
                return WolfPeriod(freq=Frequency.Y, y=self.y + n, fy_start_month=self.fy_start_month)
            case _:
                raise ValueError("サポートされていない頻度")

    def __sub__(self, other: object) -> Union[int, "WolfPeriod"]:
        """期間の減算または期間間の差分を計算します。
        
        Parameters
        ----------
        other : object
            減算する値または期間
        
        Returns
        -------
        int | WolfPeriod
            整数の場合は新しい期間、WolfPeriodの場合は期間数
        """
        if isinstance(other, int):
            return self.__add__(-other)
        if isinstance(other, WolfPeriod):
            self._ensure_same_mode(other)
            match self.freq:
                case Frequency.D:
                    return (self.start_date - other.start_date).days
                case Frequency.W:
                    return (self.start_date - other.start_date).days // 7
                case Frequency.M:
                    return (self.y - other.y) * 12 + ((self.m or 1) - (other.m or 1))
                case Frequency.Q:
                    a = (self.y * 4 + (int(self.q or 1) - 1))
                    b = (other.y * 4 + (int(other.q or 1) - 1))
                    return a - b
                case Frequency.Y:
                    return self.y - other.y
                case _:
                    raise ValueError("サポートされていない頻度")
        raise TypeError("サポートされていない減算")

    # -------- 変換 --------
    def to_pandas_period(self):
        """同じ期間を表すpandas Periodを作成します。
        
        Returns
        -------
        pandas.Period
            対応するpandas Periodオブジェクト
        """
        import pandas as pd
        match self.freq:
            case Frequency.D:
                return pd.Period(self.start_date, freq="D")
            case Frequency.W:
                freq = f"W-{self.week_start.name[:3]}"
                return pd.Period(self.start_date, freq=freq)
            case Frequency.M:
                return pd.Period(f"{self.y}-{self.m:02d}", freq="M")
            case Frequency.Q:
                end_month = ((self.fy_start_month - 2) % 12) + 1
                alias = calendar.month_abbr[end_month].upper()
                return pd.Period(self.start_date, freq=f"Q-{alias}")
            case Frequency.Y:
                end_month = ((self.fy_start_month - 2) % 12) + 1
                alias = calendar.month_abbr[end_month].upper()
                return pd.Period(self.start_date, freq=f"A-{alias}")
            case _:
                raise ValueError("サポートされていない頻度")

    # -------- シリアライゼーション（辞書） --------
    def to_dict(self) -> Dict[str, Any]:
        """WolfPeriodを辞書形式に変換します。
        
        Returns
        -------
        Dict[str, Any]
            期間オブジェクトの辞書表現
        """
        dct: Dict[str, Any] = {
            "freq": self.freq.value,
            "y": self.y,
            "week_start": self.week_start.name,
            "fy_start_month": self.fy_start_month,
        }
        if self.m is not None: dct["m"] = self.m
        if self.d is not None: dct["d"] = self.d
        if self.q is not None: dct["q"] = int(self.q)
        return dct

    @staticmethod
    def from_dict(dct: Dict[str, Any]) -> "WolfPeriod":
        """辞書からWolfPeriodを作成します。
        
        Parameters
        ----------
        dct : Dict[str, Any]
            期間オブジェクトの辞書表現
        
        Returns
        -------
        WolfPeriod
            復元された期間オブジェクト
        """
        f = Frequency(dct["freq"])
        week_start = Weekday[dct.get("week_start", "MON")]
        fy_start = int(dct.get("fy_start_month", 4))
        y = int(dct["y"])
        m = int(dct["m"]) if "m" in dct else None
        d = int(dct["d"]) if "d" in dct else None
        q = QuarterIndex(dct["q"]) if "q" in dct else None
        return WolfPeriod(freq=f, y=y, m=m, d=d, week_start=week_start, fy_start_month=fy_start, q=q)

    # -------- 特殊メソッド --------
    def __repr__(self) -> str:
        """開発者向けの文字列表現を返します。"""
        parts: list[str] = [
            f"freq={self.freq.name}",
            f"y={self.y}",
        ]
        if self.m is not None:
            parts.append(f"m={self.m:02d}")
        if self.d is not None:
            parts.append(f"d={self.d:02d}")
        if self.q is not None:
            parts.append(f"q={int(self.q)}")
        # 設定系（該当頻度で強調）
        match self.freq:
            case Frequency.W:
                parts.append(f"week_start={self.week_start.name}")
            case Frequency.Q | Frequency.Y:
                parts.append(f"fy_start_month={self.fy_start_month}")
        # 期間境界
        parts.append(f"start={self.start_date.isoformat()}")
        parts.append(f"end={self.end_date.isoformat()}")
        return f"WolfPeriod({', '.join(parts)})"

    def __str__(self) -> str:
        """人間に読みやすい文字列表現を返します。"""
        return self.label
